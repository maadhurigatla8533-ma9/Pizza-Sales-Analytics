-- Query 1: Total number of orders
SELECT COUNT(order_id) AS total_orders
FROM orders;