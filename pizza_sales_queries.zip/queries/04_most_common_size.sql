-- Query 4: Most common pizza size (by order count)
SELECT p.size,
       COUNT(od.order_details_id) AS order_count
FROM pizzas p
JOIN order_details od ON p.pizza_id = od.pizza_id
GROUP BY p.size
ORDER BY order_count DESC;