-- Query 11: Percentage contribution of each pizza category to total revenue
WITH category_revenue AS (
    SELECT pt.category,
           ROUND(SUM(od.quantity * p.price), 2) AS revenue
    FROM pizza_types pt
    JOIN pizzas p ON pt.pizza_type_id = p.pizza_type_id
    JOIN order_details od ON od.pizza_id = p.pizza_id
    GROUP BY pt.category
)
SELECT category,
       revenue,
       ROUND(revenue / (SELECT SUM(revenue) FROM category_revenue) * 100, 2) AS pct_contribution
FROM category_revenue
ORDER BY revenue DESC;