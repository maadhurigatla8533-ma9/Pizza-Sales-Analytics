-- Query 10: Top 3 pizzas by revenue (overall)
SELECT pt.name AS pizza_name,
       ROUND(SUM(od.quantity * p.price), 2) AS revenue
FROM pizza_types pt
JOIN pizzas p ON pt.pizza_type_id = p.pizza_type_id
JOIN order_details od ON od.pizza_id = p.pizza_id
GROUP BY pt.name
ORDER BY revenue DESC
LIMIT 3;