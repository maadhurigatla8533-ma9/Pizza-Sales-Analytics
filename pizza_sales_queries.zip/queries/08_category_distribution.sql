-- Query 8: Category-wise pizza distribution
SELECT category, COUNT(name) AS pizza_varieties
FROM pizza_types
GROUP BY category;